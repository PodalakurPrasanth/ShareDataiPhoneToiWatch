//
//  InterfaceController.swift
//  ShareDataiPhoneToiWatch WatchKit Extension
//
//  Created by prasanth.podalakur on 6/30/17.
//  Copyright © 2017 Kelltontech. All rights reserved.
//

import WatchKit
import Foundation
import WatchConnectivity


class InterfaceController: WKInterfaceController, WCSessionDelegate {

    @IBOutlet var imageVieww: WKInterfaceImage!
    var session : WCSession!
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        if WCSession.isSupported() {
           self.session = WCSession.default()
            self.session.delegate = self
            self.session.activate()
        }
        let status = UserDefaults.standard.object(forKey: "loginStatus") as? String
        if status == "success" {
            self.imageVieww.setImage(UIImage(named: "login-successful"))
        }else{
            self.imageVieww.setImage(UIImage(named: "sorryTryAgain"))
        }
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    @IBAction func sendButtonAction() {
        self.sendMessage()
    }
    
    
    func sendMessage(){
        let messagetoSend = ["Message":"Hey iPhone This is iWatch Prasanth"]
        self.session.sendMessage(messagetoSend, replyHandler: { (replyMessage) in
            
            let value = replyMessage["Message"] as? String
            
            // Set message label text with value
            print("\(String(describing: value))")

            
        }) { (error) in
            print("get error \(error)")
        }
    }
    
    //MARK: - WatchSessionProtocol
    
    func session(_ session: WCSession, didReceiveMessage message: [String : Any], replyHandler: @escaping ([String : Any]) -> Void) {
        print(message)
        let value = message["Message"] as? String
        

        
        let defaults = UserDefaults.standard
        defaults.set(value, forKey: "loginStatus")
        
        // GCD - Present on the screen
        DispatchQueue.main.async { () -> Void in
           if value == "success"{
            self.imageVieww.setImage(UIImage(named: "login-successful"))
           }else{
             self.imageVieww.setImage(UIImage(named: "sorryTryAgain"))
            }
        }
        
        // Send a reply
        replyHandler(["Message":" yeah Success"])
    }
    
    
    @available(watchOS 2.2, *)
    public func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        let applicationContext = session.receivedApplicationContext
        print(applicationContext)
        
        let value = applicationContext["Message"] as? String
        
        
        
        let defaults = UserDefaults.standard
        defaults.set(value, forKey: "loginStatus")
        
        // GCD - Present on the screen
        DispatchQueue.main.async { () -> Void in
            if value == "success"{
                self.imageVieww.setImage(UIImage(named: "login-successful"))
            }else{
                self.imageVieww.setImage(UIImage(named: "sorryTryAgain"))
            }
        }
    }

}





//        let storageKey = "group.com.KelltontechSolutions.ShareDataiPhoneToiWatch.watchkitapp"
//        let userStorage = UserDefaults(suiteName: storageKey)
//        print("\(String(describing: userStorage?.object(forKey: "isDarkModeEnabled")))")




