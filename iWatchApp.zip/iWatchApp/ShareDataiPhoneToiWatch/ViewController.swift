//
//  ViewController.swift
//  ShareDataiPhoneToiWatch
//
//  Created by prasanth.podalakur on 6/30/17.
//  Copyright © 2017 Kelltontech. All rights reserved.
//

import UIKit
import WatchConnectivity
class ViewController: UIViewController,WCSessionDelegate {

    @IBOutlet weak var userNameTextfield: UITextField!
    @IBOutlet weak var userPasswordTextFiels: UITextField!
     fileprivate var session: WCSession!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if WCSession.isSupported() {
            self.session = WCSession.default()
            self.session.delegate = self
            self.session.activate()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func loginAction(_ sender: Any) {
        self.sendMessages(msg: "success")
        do {
            try session.updateApplicationContext(["Message":"success"])
        } catch let error as NSError {
            NSLog("Updating the context failed: " + error.localizedDescription)
        }
    }

    @IBAction func logoutAction(_ sender: UIButton) {
        self.sendMessages(msg: "fail")
        
        do {
            try session.updateApplicationContext(["Message":"fail"])
        } catch let error as NSError {
            NSLog("Updating the context failed: " + error.localizedDescription)
        }
        
    }
    func sendMessages(msg:String)  {
        
        //group.com.KelltontechSolutions.ShareDataiPhoneToiWatch.watchkitapp
        let userName = self.userNameTextfield.text
        let password = self.userPasswordTextFiels.text
        let sendDict = ["username":userName,"passowrd":password,"Message":msg]
        self.session.sendMessage((sendDict as AnyObject) as! [String : Any] , replyHandler: { (replyMessage) in
            
            DispatchQueue.main.async(execute: {
                print("Reply Message \(replyMessage)")
            })
            
        }) { (error) in
            print(error.localizedDescription)
        }
    }
    
    //MARK: - WatchSessionProtocol
    
    func session(_ session: WCSession, didReceiveMessage message: [String : Any], replyHandler: @escaping ([String : Any]) -> Void) {
        let value = message["Message"] as? String
        
        DispatchQueue.main.async(execute: {
            print("Received Message \(String(describing: value))")
        })
        
    }
    
    @available(iOS 9.3, *)
    public func sessionDidDeactivate(_ session: WCSession) {
        // .. do some stuf here
    }
    @available (iOS 9.3, *)
    public func sessionDidBecomeInactive(_ session: WCSession) {
        //...
    }
    @available(iOS 9.3, *)
    public func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        //...
        
        let applicationContext = session.receivedApplicationContext
        print(applicationContext)
    }
}

